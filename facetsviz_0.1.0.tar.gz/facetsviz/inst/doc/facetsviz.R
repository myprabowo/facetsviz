## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----eval = FALSE-------------------------------------------------------------
# library(facetsviz)
# 
# facets <- read_facets_out("peerAssessment.out")
# names(facets$measurement_reports)
# plot_wright_map(facets)

## ----eval = FALSE-------------------------------------------------------------
# render_facets_plots(facets, output_dir = "figures", formats = c("png", "tiff"))

